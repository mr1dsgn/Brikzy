<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PageController@index');
Route::get('/about', 'PageController@about');
Route::get('/projects', 'ProjectController@index');
Route::get('/projects/{id}', 'ProjectController@view');
Route::get('/units', 'UnitController@index');
Route::get('/units/{id}', 'UnitController@view');
Route::get('/offers', 'UnitController@indexoffer');
Route::get('/offers/{id}', 'UnitController@viewoffer');
Route::get('/contact', 'PageController@contact');
Route::get('/videos', 'VideoController@index');
Route::get('/videos/{id}', 'VideoController@view');
Route::get('/photos', 'PhotoController@index');
Route::get('/photos/{id}', 'PhotoController@view');
Route::get('/pdfs', 'PdfController@index');
Route::get('/sitemap.xml', 'PageController@sitemap');
Route::get('/language/ar', 'PageController@ar');
Route::get('/language/en', 'PageController@en');

Route::post('/contact', 'PageController@postContact');
Route::post('/subscribe', 'PageController@postSubscribe');
Route::post('/callme', 'PageController@postCallme');

Auth::routes();