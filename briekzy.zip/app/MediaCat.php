<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MediaCat extends Model
{
    //
    public function pdfs(){
        return $this->hasMany('App\Pdf');
    }

    public function photos(){
        return $this->hasMany('App\Photo');
    }

    public function videos(){
        return $this->hasMany('App\Video');
    }
}
