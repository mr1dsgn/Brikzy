<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    //
    public function photos(){
        return $this->hasMany('App\ProjectPhoto');
    }

    public function units(){
        return $this->hasMany('App\Unit');
    }
}
