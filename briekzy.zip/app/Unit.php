<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use \App\Location;
class Unit extends Model
{
    //
    public function location(){
        return $this->belongsTo('App\Location');
    }

    public function type(){
        return $this->belongsTo('App\Type');
    }

    public function project(){
        return $this->belongsTo('App\Project');
    }
    //
    public function photos(){
        return $this->hasMany('App\UnitPhoto');
    }
}
