<?php 
return [
    'ourcompany'=>'شركتنا',
    'history'=>'تاريخ الشركة',
    'brickzey'=>'شركة بريكزي',
    'values'=>'القيم',
    'ourvalues'=>'قيمنا',
    'ourmission'=>'مهمتنا',
    'ourvision'=>'رؤيتنا',
    ];