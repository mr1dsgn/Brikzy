<?php 
return [
    'firstname'=>'الإسم الأول',
    'lastname'=>'الإسم الاخير',
    'email'=>'البريد الاليكتروني',
    'message'=>'الرسالة',
    'contactdetails'=>'بيانات الإتصال',
    'sendmessage'=>'إرسل',
    'welcome'=>'برجاء إدخال بياناتك وسيتم الإتصال بك في افرب وقت',
    'number'=>'الهاتف',
    'close'=>'إلغاء'
    ];