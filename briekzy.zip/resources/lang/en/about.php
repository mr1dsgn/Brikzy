<?php 
return [
    'ourcompany'=>'Our Company',
    'history'=>'Company History',
    'brickzey'=>'BRICKZEY Property Management',
    'values'=>'Values',
    'ourvalues'=>'Our Values',
    'ourmission'=>'Our Mission',
    'ourvision'=>'Our Vision',
    ];