<?php 
return [
    'firstname'=>'First Name',
    'lastname'=>'Last Name',
    'email'=>'Email',
    'message'=>'Message',
    'contactdetails'=>'Contact Details',
    'sendmessage'=>'Send Message',
    'welcome'=>'Please enter your details and our agent will contact you soon',
    'number'=>'Phone Number',
    'close'=>'Close'
    ];