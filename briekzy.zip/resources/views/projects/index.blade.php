@extends('layouts.app')
@section('content')
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                    <a href="{{url('')}}">{{__('home.home')}}</a> / <span>{{__('home.projects')}}</span>
                  </div>
                  <h1>{{__('home.projects')}}</h1>
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->
      @php
      $i=0;
      @endphp

@if(count($primeLocation)>0)
<section class="probootstrap-section">
    <div class="container">
      <div class="row heading">
        <h2 class="mt0 mb50 text-center">{{__('home.primeProjects')}}</h2>
      </div>
      <div class="row probootstrap-gutter10">
        @foreach($primeLocation as $l)
        <div class="col-md-4 col-sm-6">
          @if(app()->getLocale()=='ar')
          <h2 style="text-align:center;color:#912417">{{$l['name_ar']}}</h2>
          @else
          <h2 style="text-align:center;color:#912417">{{$l['name_en']}}</h2>
          @endif
          <div id="myCarousel{{$i}}" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                @for($j=0;$j<count($l['projects']);$j++)
                  <li data-target="#myCarousel{{$i}}" data-slide-to="{{$j}}" class="{{($j==0)?'active':''}}"></li>
                @endfor
              </ol>
              <!-- Wrapper for slides -->
              <div class="carousel-inner">

                @for($j=0;$j<count($l['projects']);$j++)
                  <div class="item {{($j==0)?'active':''}}">
                      <div class="hovereffect">
                          @if(app()->getLocale() == "en")
                          <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_en}}" class="img-responsive">
                          @else
                          <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_ar}}" class="img-responsive">
                          @endif
                          <div class="overlay">
                              @if(app()->getLocale() == "en")
                              <h3>{{$l['projects'][$j]->name_en}}</h3>
                              @else
                              <h3>{{$l['projects'][$j]->name_ar}}</h3>
                              @endif
                             <a class="info" href="{{url('projects/'.$l['projects'][$j]->id)}}">{{__('home.details')}}</a>
                          </div>
                      </div>
                  </div>
                @endfor
              <!-- Left and right controls -->

              <a class="left carousel-control" href="#myCarousel{{$i}}" data-slide="prev">
                  <span class="glyphicon-chevron-left icon-chevron-left"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel{{$i++}}" data-slide="next">
                  <span class="glyphicon-chevron-right icon-chevron-right"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
          </div>
        </div>
        @endforeach
      </div>  
  </section>
  @endif

        @if(count($execlusiveLocation)>0)
      <section class="probootstrap-section">
          <div class="container">
            <div class="row heading">
              <h2 class="mt0 mb50 text-center">{{__('home.execlusiveProjects')}}</h2>
            </div>
            <div class="row probootstrap-gutter10">
              @foreach($execlusiveLocation as $l)
              <div class="col-md-4 col-sm-6">
                  @if(app()->getLocale()=='ar')
                  <h2 style="text-align:center;color:#912417">{{$l['name_ar']}}</h2>
                  @else
                  <h2 style="text-align:center;color:#912417">{{$l['name_en']}}</h2>
                  @endif
                <div id="myCarousel{{$i}}" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      @for($j=0;$j<count($l['projects']);$j++)
                        <li data-target="#myCarousel{{$i}}" data-slide-to="{{$j}}" class="{{($j==0)?'active':''}}"></li>
                      @endfor
                    </ol>
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                      @for($j=0;$j<count($l['projects']);$j++)
                        <div class="item {{($j==0)?'active':''}}">
                            <div class="hovereffect">
                                @if(app()->getLocale() == "en")
                                <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_en}}" class="img-responsive">
                                @else
                                <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_ar}}" class="img-responsive">
                                @endif
                                <div class="overlay">
                                    @if(app()->getLocale() == "en")
                                    <h3>{{$l['projects'][$j]->name_en}}</h3>
                                    @else
                                    <h3>{{$l['projects'][$j]->name_ar}}</h3>
                                    @endif
                                   <a class="info" href="{{url('projects/'.$l['projects'][$j]->id)}}">{{__('home.details')}}</a>
                                </div>
                            </div>
                        </div>
                      @endfor
                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel{{$i}}" data-slide="prev">
                      <span class="glyphicon-chevron-left icon-chevron-left"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel{{$i++}}" data-slide="next">
                      <span class="glyphicon-chevron-right icon-chevron-right"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                </div>
            </div>
              @endforeach
          </div>
        </section>
        @endif

@endsection