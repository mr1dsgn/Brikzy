@extends('layouts.app')
@section('content')
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                  <a href="{{url('')}}">{{__('home.home')}}</a> / <a href="{{url('projects')}}"><span>{{__('home.projects')}}</span></a>
                  </div>
                  @if(app()->getLocale()=='en')
                  <h1>{{$project->name_en}}</h1>
                  @else
                  <h1>{{$project->name_ar}}</h1>
                  @endif
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->
      <section class="probootstrap-section">
          <div class="container">
            <div class="row">
              <div class="col-md-6">
                @if(app()->getLocale()=='en')
                {!! $project->content_en !!}
                @else
                {!! $project->content_ar !!}
                @endif
                <br />
              <button id='callMeBtn' class="btn btn-primary" style="margin:5px;" type="submit"  data-toggle="modal" data-target="#exampleModalCenter"><i class="icon-phone2 t2"></i> {{__('home.callme')}}</button>
                <a id='callMeLnk' href="tel:19693" class="btn btn-primary" style="margin:5px;width: fit-content"><i class="icon-phone2 t2"></i> {{__('home.callme')}}</a>
              </div>
              <div class="col-md-6">
                @if(app()->getLocale()=='en')
                <img src="{{url($project->image)}}" style="width:100%;heigh:auto;" alt="{{$project->name_en}}"/>
                @else
                <img src="{{url($project->image)}}" style="width:100%;heigh:auto;" alt="{{$project->name_ar}}"/>
                @endif
            </div>
          </div>
        </section>

        @php
        $photos = $project->photos()->get();
        $i=1;
        @endphp

@if(count($photos)>0)

<div id="gallery" style="display:none;">

    @foreach($photos as $photo)
      @if(app()->getLocale()=='en')
      <img alt="{{$photo->name_en}}" src="{{url($photo->image)}}" data-image="{{url($photo->image)}}" data-description="{{$photo->name_en}}">
      @else
      <img alt="{{$photo->name_ar}}" src="{{url($photo->image)}}" data-image="{{url($photo->image)}}" data-description="{{$photo->name_ar}}">
      @endif
    @endforeach
{{-- 
		<img alt="Youtube Video"
			 data-type="youtube"
			 data-videoid="A3PDXmYoF5U"
			 data-description="You can include youtube videos easily!">
			  --}}			 			 
	</div>
  @endif
<div class="container">
  <div class="row">
      @php
      $i=0;
      $units=$project->units()->get();
      @endphp
      @if($units && count($units)>0)
      <br />
      <h1 style="text-align:center;">{{__('home.units')}}</h1>
      @endif
      @foreach($units as $unit)
      <div class="col-md-4 col-sm-6">
        <div class="probootstrap-card probootstrap-listing">
          <div class="probootstrap-card-media">
            @if(app()->getLocale() == "en")
            <img src="{{url($unit->image)}}" class="img-responsive" alt="{{$unit->name_en}}">
            @else
            <img src="{{url($unit->image)}}" class="img-responsive" alt="{{$unit->name_ar}}">
            @endif
          </div>
          <div class="probootstrap-card-text">
            <h2 class="probootstrap-card-heading">
              <a href="{{url('units/'.$unit->id)}}">
                @if(app()->getLocale() == "en")
                {{$unit->name_en}}
                @else
                {{$unit->name_ar}}
                @endif
              </a>
            </h2>
            <div class="probootstrap-listing-location">
                @if(app()->getLocale() == "en")
                <span>{{$unit->description_en}}</span>
                @else
                <span>{{$unit->description_ar}}</span>
                @endif
            </div>
            <div class="probootstrap-listing-price"><strong> {{$unit->price.' '.__('home.egp')}} </strong></div>
          </div>
          <div class="probootstrap-card-extra">
            <ul>
              <li>
                  {{__('home.area')}}
                <span>{{$unit->area .' '.__('home.m2')}}</span>
              </li>
              <li>
                  {{__('home.beds')}}
                <span>{{$unit->beds}}</span>
              </li>
              <li>
                  {{__('home.baths')}}
                <span>{{$unit->baths}}</span>
              </li>
              <li>
                  {{__('home.location')}}
                @php
                $location=$unit->location()->first();
                @endphp
                @if(app()->getLocale() == "en")
                <span>{{$location->name_en}}</span>
                @else
                <span>{{$location->name_ar}}</span>
                @endif
              </li>
            </ul>
          </div>
        </div>
        <!-- END listing -->
      </div>
      @if((++$i)%2==0)
      <div class="clearfix visible-sm-block"></div>
      @endif
      @endforeach
    </div>
  </div>
  <div id="map"></div>
    @endsection

@section('css')
<link rel='stylesheet' href='{{url('assets')}}/unitegallery/css/unite-gallery.css' type='text/css' />
@endsection
@section('scripts')
  
<script>
        
    function initMap() {
        var latitude = 30.019949;
        var longitude = 31.003611;
        var uluru = {lat: latitude, lng: longitude};
        var map = new google.maps.Map(document.getElementById('map'), {
        center: uluru,
        zoom: 15
      });
      
      var marker = new google.maps.Marker({
        position: uluru,
        map: map
      });
    }

  </script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCexG_fKuUyNzxEYYZHd_2rngKejCQnzbw&callback=initMap"
  async defer></script>
<script type='text/javascript' src='{{url('assets')}}/unitegallery/js/unitegallery.min.js'></script>
<script type='text/javascript' src='{{url('assets')}}/unitegallery/themes/tilesgrid/ug-theme-tilesgrid.js'></script>

<script type="text/javascript">
function detectmob() { 
  if( navigator.userAgent.match(/Android/i)
  || navigator.userAgent.match(/webOS/i)
  || navigator.userAgent.match(/iPhone/i)
  || navigator.userAgent.match(/iPad/i)
  || navigator.userAgent.match(/iPod/i)
  || navigator.userAgent.match(/BlackBerry/i)
  || navigator.userAgent.match(/Windows Phone/i)
  ){
     return true;
   }
  else {
     return false;
   }
 }
  jQuery(document).ready(function(){
     jQuery("#gallery").unitegallery();
     if(detectmob()){
       $('#callMeBtn').css('display','none');
       $('#callMeLnk').css('display','block');
     }else{
       $('#callMeLnk').css('display','none');
       $('#callMeBtn').css('display','block');
     }
   });
</script>
@endsection