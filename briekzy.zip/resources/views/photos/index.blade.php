@extends('layouts.app')
@section('css')
<style>
  .thumbnail {
    position:relative;
    overflow:hidden;
}
 
.caption {
    position:absolute;
    top:-100%;
    right:0;
    background:rgba(66, 139, 202, 0.75);
    width:100%;
    height:100%;
    padding:2%;
    text-align:center;
    color:#fff !important;
    z-index:2;
    -webkit-transition: all 0.5s ease-in-out;
    -moz-transition: all 0.5s ease-in-out;
    -o-transition: all 0.5s ease-in-out;
    -ms-transition: all 0.5s ease-in-out;
    transition: all 0.5s ease-in-out;
}
.thumbnail:hover .caption {
    top:0%;
}
    
  </style>
@endsection
@section('content')
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                      <a href="{{url('')}}">{{__('home.home')}}</a> / <span>{{__('home.photos')}}</span>
                  </div>
                  <h1>{{__('home.photos')}}</h1>
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->

      <section class="probootstrap-section probootstrap-section-lighter">
          <div class="container">
            <div class="row heading">
              <h2 class="mt0 mb50 text-center">{{__('home.photos')}}</h2>
            </div>
            
<div class="container">
  
    <div class="row">
        @foreach($media_cats as $m)
        <div class="col-xs-6 col-sm-4 col-md-4">            
            <a href="{{url('photos/'.$m->id)}}">
            <div class="thumbnail">
                <div class="caption">
                    @if(app()->getLocale() == "en")
                    <h4>{{$m->name_en}}</h4>
                    <p>{{$m->description_en}}</p>
                    @else
                    <h4>{{$m->name_ar}}</h4>
                    <p>{{$m->description_ar}}</p>
                    @endif
                </div>
                @if(app()->getLocale() == "en")
                <img src="{{url($m->image)}}" alt="{{$m->name_en}}">
                @else
                <img src="{{url($m->image)}}" alt="{{$m->name_ar}}">
                @endif
            </div>
            </a>
            <h5 style="text-align:center;">{{$m->cat_date}}</h5>
        </div>
        @endforeach
    </div>
</div><!-- /.container -->
          </div>
</section>   
      @endsection