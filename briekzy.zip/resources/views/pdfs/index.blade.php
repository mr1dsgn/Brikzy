@extends('layouts.app')
@section('css')
@endsection
@section('content')
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                      <a href="{{url('')}}">{{__('home.home')}}</a> / <span>{{__('home.newsletter')}}</span>
                  </div>
                  <h1>{{__('home.newsletter')}}</h1>
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->

      <section class="probootstrap-section probootstrap-section-lighter">
          <div class="container">
            <div class="row heading">
              <h2 class="mt0 mb50 text-center">{{__('home.newsletter')}}</h2>
            </div>
            
<div class="container">
  
    <div class="row">
        @foreach($media_cats as $m)
        <div class="col-md-12">  
            @if(app()->getLocale()=='en')
            <h1>{{$m->name_en}}</h1>
            <h6>{{$m->description_en}}</h6>
            @else
            <h1>{{$m->name_ar}}</h1>
            <h6>{{$m->description_ar}}</h6>
            @endif
            @php
            $pdfs = $m->pdfs()->get();
            @endphp
            @foreach($pdfs as $p)
            @if(app()->getLocale()=='en')
            <a target="_blank" href="{{url($p->pdf)}}">{{$p->name_en}}</a>
            @else 
            <a target="_blank" href="{{url($p->pdf)}}">{{$p->name_ar}}</a>
            @endif
            @endforeach
        </div>
        @endforeach
    </div>
</div><!-- /.container -->
          </div>
        </section>   
      @endsection