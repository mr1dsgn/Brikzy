@extends('layouts.app')

@section('content')
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                      <a href="{{url('')}}">{{__('home.home')}}</a> / <a href="{{url('videos')}}"><span>{{__('home.videos')}}</span></a>
                  </div>
                  @if(app()->getLocale()=='en')
                  <h1>{{$media_cat->name_en}}</h1>
                  @else
                  <h1>{{$media_cat->name_ar}}</h1>
                  @endif
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->

      <section class="probootstrap-section probootstrap-section-lighter">
            <div class="container">
              <div class="row heading">
                  @if(app()->getLocale()=='en')                
                  <h2 class="mt0 mb50 text-center">{{$media_cat->name_en}}</h2>
                  @else
                  <h2 class="mt0 mb50 text-center">{{$media_cat->name_ar}}</h2>
                  @endif
            </div>
  <div class="container">
    
      <div class="row">
          @php
          $photos = $media_cat->photos()->get();
          $i=1;
          @endphp
  
  @if(count($photos)>0)
  
  <div id="gallery" style="display:none;">
  
      @foreach($photos as $photo)
        @if(app()->getLocale()=='en')
        <img alt="{{$photo->name_en}}" src="{{url($photo->image)}}" data-image="{{url($photo->image)}}" data-description="{{$photo->name_en}}">
        @else
        <img alt="{{$photo->name_ar}}" src="{{url($photo->image)}}" data-image="{{url($photo->image)}}" data-description="{{$photo->name_ar}}">
        @endif
      @endforeach
    </div>
    @endif
      </div>
  </div><!-- /.container -->
            </div>
  </section>
@endsection

@section('css')
<link rel='stylesheet' href='{{url('assets')}}/unitegallery/css/unite-gallery.css' type='text/css' />
@endsection
@section('scripts')
  
<script type='text/javascript' src='{{url('assets')}}/unitegallery/js/unitegallery.min.js'></script>
<script type='text/javascript' src='{{url('assets')}}/unitegallery/themes/tilesgrid/ug-theme-tilesgrid.js'></script>

<script type="text/javascript">
  jQuery(document).ready(function(){
    jQuery("#gallery").unitegallery();
  });
</script>
@endsection