<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>http://brickzey.com/</loc>
    </url>
    <url>
        <loc>http://brickzey.com/about</loc>
    </url>
    <url>
        <loc>http://brickzey.com/projects</loc>
    </url>
    <url>
        <loc>http://brickzey.com/units</loc>
    </url>

    <url>
      <loc>http://brickzey.com/offers</loc>
    </url>
    <url>
      <loc>http://brickzey.com/photos</loc>
    </url>
    <url>
      <loc>http://brickzey.com/videos</loc>
    </url>
    <url>
      <loc>http://brickzey.com/pdfs</loc>
    </url>
    <url>
      <loc>http://brickzey.com/contact</loc>
    </url>
    @foreach($projects as $project)
        <url>
            <loc>http://brickzey.com/projects/{{ $project->id }}</loc>
        </url>
    @endforeach
    @foreach($units as $project)
        <url>
            <loc>http://brickzey.com/units/{{ $project->id }}</loc>
        </url>
    @endforeach
    @foreach($offers as $project)
        <url>
            <loc>http://brickzey.com/offers/{{ $project->id }}</loc>
        </url>
    @endforeach
</urlset>