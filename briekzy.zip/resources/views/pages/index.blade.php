@extends('layouts.app')
@section('content')
@php
$details=$page->details();
@endphp
<section class="probootstrap-slider flexslider">
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <div id="searchDiv" class="probootstrap-home-search probootstrap-animate">
                <div href="#" id="closeSearch" style="position: absolute;right: 30px;margin-top: -19px;cursor:pointer">X</div>
                <form action="{{url('units')}}" method="get">
                    <h2 class="heading">{{__('home.search')}}</h2>
                    <div class="probootstrap-field-group">
                        <div class="probootstrap-fields" style="width:100%">
                            <div class="search-category" style="width:50%">                            
                              <input name="keywords" type="text" class="form-control" placeholder="{{__('home.keywords')}}">
                              </div>
                              <div class="search-category" style="width:50%">
                                  <i class="icon-chevron-down"></i>
                                  <select name="type" id="" class="form-control">
                                    <option value="">{{__('home.type')}}</option>
                                    @foreach($types as $type)
                                    @if(app()->getLocale()=='en')
                                    <option value="{{$type->id}}">{{$type->name_en}}</option>
                                    @else
                                    <option value="{{$type->id}}">{{$type->name_ar}}</option>
                                    @endif
                                    @endforeach
                                  </select>
                              </div>  
                        </div>
                        <div class="probootstrap-fields" style="width:100%">
                              <div class="col-md-6" style="padding:5px;">
                                  <div class="col-xs-6" style="padding:0px;">
                                      <input name="priceFrom" type="number" class="form-control" placeholder="{{__('home.priceFrom').' ('.__('home.egp').')'}}">
                                    </div>
                                    <div class="col-xs-6" style="padding:0px;">
                                        <input name="priceTo" type="number" class="form-control" placeholder="{{__('home.priceTo').' ('.__('home.egp').')'}}">
                                      </div>
                                  
                                </div>
                                <div class="col-md-6" style="padding:5px;">
                                    <div class="col-xs-6" style="padding:0px;">
                                        <input name="areaFrom" type="number" class="form-control" placeholder="{{__('home.areaFrom').' ('.__('home.sqm').')'}}">
                                      </div>
                                      <div class="col-xs-6" style="padding:0px;">
                                          <input name="areaTo" type="number" class="form-control" placeholder="{{__('home.areaTo').' ('.__('home.sqm').')'}}">
                                        </div>
                                  </div>
                                  <div class="col-md-12" style="padding:5px;width:100%">
                                      <div class="col-xs-4" style="padding:0px;">
                                          <select name="bathrooms" id="" class="form-control">
                                              <option value="">{{__('home.bathrooms')}}</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                              <option value="4">4</option>
                                              <option value="5">5</option>
                                              <option value="6">6</option>
                                              <option value="7">7</option>
                                              <option value="8">8</option>
                                              <option value="9">9</option>
                                              <option value="10">10</option>
                                          </select>
                                        </div>
                                      <div class="col-xs-4" style="padding:0px;">
                                          <select name="bedrooms" id="" class="form-control">
                                              <option value="">{{__('home.bedrooms')}}</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                              <option value="4">4</option>
                                              <option value="5">5</option>
                                              <option value="6">6</option>
                                              <option value="7">7</option>
                                              <option value="8">8</option>
                                              <option value="9">9</option>
                                              <option value="10">10</option>
                                          </select>
                                      </div>
                                      <div class="col-xs-4" style="padding:0px;">
                                          <select name="garages" id="" class="form-control">
                                              <option value="">{{__('home.garages')}}</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                              <option value="4">4</option>
                                              <option value="5">5</option>
                                              <option value="6">6</option>
                                              <option value="7">7</option>
                                              <option value="8">8</option>
                                              <option value="9">9</option>
                                              <option value="10">10</option>
                                          </select>
                                      </div>
                                    </div>
                      </div>
                      <div class="probootstrap-fields">
                          <div class="search-category" style="width:100%">
                              <i class="icon-chevron-down"></i>
                              <select name="location" id="" class="form-control">
                                <option value="">{{__('home.location')}}</option>
                                @foreach($locations as $location)
                                @if(app()->getLocale()=='en')
                                <option value="{{$location->id}}">{{$location->name_en}}</option>
                                @else
                                <option value="{{$location->id}}">{{$location->name_ar}}</option>
                                @endif
                                @endforeach
                              </select>
                          </div>
                      </div>
                      
                      <button class="btn btn-primary" style="margin:5px;" type="submit"><i class="icon-magnifying-glass t2"></i> {{__('home.searchbutton')}}</button>
                    </div>
                  </form>
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->
      @php
      $i=0;
      if(isset($details['mission'])){
        $i++;
      }
      if(isset($details['vision'])){
        $i++;
      }
      if(isset($details['values'])){
        $i++;
      }
      @endphp
      @if($i>0)
      <section class="probootstrap-section probootstrap-section-lighter">
        <div class="container">
          <div class="row">
            @if(isset($details['mission']))
            <div class="col-md-{{12/$i}}">
              <div class="probootstrap-card text-center probootstrap-animate">
                <div class="probootstrap-card-media svg-sm colored">
                  <img src="{{URL('')}}/img/flaticon/svg/objective.svg" class="svg" alt="Mission">
                </div>
                <div class="probootstrap-card-text">
                  <h2 class="probootstrap-card-heading">{{__('home.mission')}}</h2>
                  @if(app()->getLocale()=='en')
                  <p>{{$details['mission']}}</p>
                  @else
                  <p>{{$details['mission_ar']}}</p>
                  @endif
                  <p><a href="{{url('/about')}}">{{__('home.more')}}</a></p>
                </div>
              </div>
            </div>
            @endif
            @if(isset($details['vision']))
            <div class="col-md-{{12/$i}}">
              <div class="probootstrap-card text-center probootstrap-animate">
                <div class="probootstrap-card-media svg-sm colored">
                  <img src="{{URL('')}}/img/flaticon/svg/creative.svg" class="svg" alt="Vision">
                </div>
                <div class="probootstrap-card-text">
                  <h2 class="probootstrap-card-heading">{{__('home.vision')}}</h2>
                  @if(app()->getLocale()=='en')
                  <p>{{$details['vision']}}</p>
                  @else
                  <p>{{$details['vision_ar']}}</p>
                  @endif
                  <p><a href="{{url('/about')}}">{{__('home.more')}}</a></p>
                </div>
              </div>
            </div>
            @endif
            @if(isset($details['values']))
            <div class="col-md-{{12/$i}}">
              <div class="probootstrap-card text-center  probootstrap-animate">
                <div class="probootstrap-card-media svg-sm colored">
                  <img src="{{URL('')}}/img/flaticon/svg/handshake.svg" class="svg" alt="Values">
                </div>
                <div class="probootstrap-card-text">
                  <h2 class="probootstrap-card-heading">{{__('home.values')}}</h2>
                  @if(app()->getLocale()=='en')
                  <p>{{$details['values']}}</p>
                  @else
                  <p>{{$details['values_ar']}}</p>
                  @endif
                  <p><a href="{{url('/about')}}">{{__('home.more')}}</a></p>
                </div>
              </div>
            </div>
            @endif
          </div>
        </div>
      </section>
      <!-- END: section -->
      @endif


      @php
      $i=0;
      @endphp

@if(count($primeLocation)>0)
<section class="probootstrap-section">
    <div class="container">
      <div class="row heading">
        <h2 class="mt0 mb50 text-center">{{__('home.primeProjects')}}</h2>
      </div>
      <div class="row probootstrap-gutter10">
        @foreach($primeLocation as $l)
        <div class="col-md-4 col-sm-6">
          @if(app()->getLocale()=='ar')
          <h2 style="text-align:center;color:#912417">{{$l['name_ar']}}</h2>
          @else
          <h2 style="text-align:center;color:#912417">{{$l['name_en']}}</h2>
          @endif
          <div id="myCarousel{{$i}}" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                @for($j=0;$j<count($l['projects']);$j++)
                  <li data-target="#myCarousel{{$i}}" data-slide-to="{{$j}}" class="{{($j==0)?'active':''}}"></li>
                @endfor
              </ol>
              <!-- Wrapper for slides -->
              <div class="carousel-inner">

                @for($j=0;$j<count($l['projects']);$j++)
                  <div class="item {{($j==0)?'active':''}}">
                      <div class="hovereffect">
                          @if(app()->getLocale() == "en")
                          <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_en}}" class="img-responsive">
                          @else
                          <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_ar}}" class="img-responsive">
                          @endif
                          <div class="overlay">
                              @if(app()->getLocale() == "en")
                              <h3>{{$l['projects'][$j]->name_en}}</h3>
                              @else
                              <h3>{{$l['projects'][$j]->name_ar}}</h3>
                              @endif
                             <a class="info" href="{{url('projects/'.$l['projects'][$j]->id)}}">{{__('home.details')}}</a>
                          </div>
                      </div>
                  </div>
                @endfor
              <!-- Left and right controls -->

              <a class="left carousel-control" href="#myCarousel{{$i}}" data-slide="prev">
                  <span class="glyphicon-chevron-left icon-chevron-left"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel{{$i++}}" data-slide="next">
                  <span class="glyphicon-chevron-right icon-chevron-right"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
          </div>
        </div>
        @endforeach
      </div>  
  </section>
  @endif

        @if(count($execlusiveLocation)>0)
      <section class="probootstrap-section">
          <div class="container">
            <div class="row heading">
              <h2 class="mt0 mb50 text-center">{{__('home.execlusiveProjects')}}</h2>
            </div>
            <div class="row probootstrap-gutter10">
              @foreach($execlusiveLocation as $l)
              <div class="col-md-4 col-sm-6">
                  @if(app()->getLocale()=='ar')
                  <h2 style="text-align:center;color:#912417">{{$l['name_ar']}}</h2>
                  @else
                  <h2 style="text-align:center;color:#912417">{{$l['name_en']}}</h2>
                  @endif
                <div id="myCarousel{{$i}}" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      @for($j=0;$j<count($l['projects']);$j++)
                        <li data-target="#myCarousel{{$i}}" data-slide-to="{{$j}}" class="{{($j==0)?'active':''}}"></li>
                      @endfor
                    </ol>
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                      @for($j=0;$j<count($l['projects']);$j++)
                        <div class="item {{($j==0)?'active':''}}">
                            <div class="hovereffect">
                                @if(app()->getLocale() == "en")
                                <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_en}}" class="img-responsive">
                                @else
                                <img src="{{url('').'/'.$l['projects'][$j]->image}}" alt="{{$l['projects'][$j]->name_ar}}" class="img-responsive">
                                @endif
                                <div class="overlay">
                                    @if(app()->getLocale() == "en")
                                    <h3>{{$l['projects'][$j]->name_en}}</h3>
                                    @else
                                    <h3>{{$l['projects'][$j]->name_ar}}</h3>
                                    @endif
                                   <a class="info" href="{{url('projects/'.$l['projects'][$j]->id)}}">{{__('home.details')}}</a>
                                </div>
                            </div>
                        </div>
                      @endfor
                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel{{$i}}" data-slide="prev">
                      <span class="glyphicon-chevron-left icon-chevron-left"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel{{$i++}}" data-slide="next">
                      <span class="glyphicon-chevron-right icon-chevron-right"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                </div>
            </div>
              @endforeach
          </div>
        </section>
        @endif
        
      <section class="probootstrap-section probootstrap-section-lighter">
        <div class="container">
          <div class="row heading">
            <h2 class="blinking mt0 mb50 text-center">{{__('home.hotoffers')}}</h2>
          </div>
          <div class="row">
            @php
            $i=0;
            @endphp
            @foreach($units as $unit)
            <div class="col-md-4 col-sm-6">
              <div class="probootstrap-card probootstrap-listing">
                <div style="text-align:center;position: absolute;z-index: 2;background: #ffffff85;display: block;width: 100%;color: #912417;">
                  <div id="countdown{{$i}}"></div>
                  @if(app()->getLocale()=='ar')
                  <div>{{$unit->offer_name_ar}}</div>
                  @else
                  <div>{{$unit->offer_name_en}}</div>
                  @endif
                </div>
                <div class="probootstrap-card-media">
                  @if(app()->getLocale() == "en")
                  <img src="{{url($unit->image)}}" class="img-responsive" alt="{{$unit->name_en}}">
                  @else
                  <img src="{{url($unit->image)}}" class="img-responsive" alt="{{$unit->name_ar}}">
                  @endif
                </div>
                <div class="probootstrap-card-text">
                  <h2 class="probootstrap-card-heading">
                    <a href="{{url('units/'.$unit->id)}}">
                      @if(app()->getLocale() == "en")
                      {{$unit->name_en}}
                      @else
                      {{$unit->name_ar}}
                      @endif
                    </a>
                  </h2>
                  <div class="probootstrap-listing-location">
                      @if(app()->getLocale() == "en")
                      <span>{{$unit->description_en}}</span>
                      @else
                      <span>{{$unit->description_ar}}</span>
                      @endif
                  </div>
                  <div class="probootstrap-listing-price"><strong> {{$unit->price.' '.__('home.egp')}} </strong></div>
                </div>
                <div class="probootstrap-card-extra">
                  <ul>
                    <li>
                        {{__('home.area')}}
                      <span>{{$unit->area .' '.__('home.m2')}}</span>
                    </li>
                    <li>
                        {{__('home.beds')}}
                      <span>{{$unit->beds}}</span>
                    </li>
                    <li>
                        {{__('home.baths')}}
                      <span>{{$unit->baths}}</span>
                    </li>
                    <li>
                        {{__('home.location')}}
                      @php
                      $location=$unit->location()->first();
                      @endphp
                      @if(app()->getLocale() == "en")
                      <span>{{$location->name_en}}</span>
                      @else
                      <span>{{$location->name_ar}}</span>
                      @endif
                    </li>
                  </ul>
                </div>
              </div>
              <!-- END listing -->
            </div>
            @if((++$i)%2==0)
            <div class="clearfix visible-sm-block"></div>
            @endif
            @endforeach
          </div>
        </div>
      </section>    
@endsection
@section('scripts')
<script type="text/javascript">
$(document).ready(function(){
  $('#closeSearch').click(function(){
    $('#searchDiv').css('display','none');
  });
});
</script>
@php
$i=0;
@endphp
<script type="text/javascript">
@foreach($units as $unit)
  $("#countdown{{$i++}}").countdown("{{$unit->end_date}}", function(event) {
    $(this).text(
      event.strftime('%D days %H:%M:%S')
    );
  });
@endforeach
</script>
@endsection
@section('css')
<style>
  .blinking {
    animation-duration: 1200ms;
    animation-name: blink;
    animation-iteration-count: infinite;
    animation-direction: alternate;
    -webkit-animation:blink 1200ms infinite; /* Safari and Chrome */
}
@keyframes blink {
    from {
        color:Yellow;
    }
    to {
        color:Red;
    }
}
@-webkit-keyframes blink {
    from {
        color:Yellow;
    }
    to {
        color:Red;
    }
}
  </style>
@endsection