@extends('layouts.app')
@section('content')
@php
$details=$page->details();
@endphp
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                    <a href="{{url('')}}">{{__('home.home')}}</a> / <span>{{__('home.about')}}</span>
                  </div>
                  <h1>{{__('home.about')}}</h1>
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->
    
      <section class="probootstrap-section">
        <div class="container">
          <div class="row heading">
            <div class="col-md-12"><h2 class="mt0 mb50 text-center">{{__('about.ourcompany')}}</h2></div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <p><img src="{{url('')}}/img/about.jpg" class="img-responsive" alt="Brickzey"></p>
            </div>
          </div>
        </div>
      </section>
    
      <section class="probootstrap-half">
        <div class="image-wrap">
          <div class="image" style="background-image: url(img/71real-estate-investment.jpg);"></div>
        </div>
        <div class="text">
            <p class="mb10 subtitle">{{__('about.history')}}</p>
            <h3 class="mt0 mb40">{{__('about.brickzey')}}</h3>
            @if(app()->getLocale()=='en')
            <p>{{$details['history']}}</p>
            @else
            <p>{{$details['history_ar']}}</p>
            @endif
          </div>        
      </section>
      <section class="probootstrap-half reverse">
        <div class="image-wrap">
          <div class="image" style="background-image: url(img/57two-basics-fundamental-of-real-estate-investing.jpg);"></div>
        </div>
        <div class="text">
            <p class="mb10 subtitle">{{__('about.values')}}</p>
            <h3 class="mt0 mb40">{{__('about.ourvalues')}}</h3>
            @if(app()->getLocale()=='en')
            <p>{{$details['values']}}</p>
            @else
            <p>{{$details['values_ar']}}</p>
            @endif
          </div>
      </section>
      <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>{{__('about.ourvision')}}</h2>
          @if(app()->getLocale()=='en')
            <p>{{$details['vision']}}</p>
            @else
            <p>{{$details['vision_ar']}}</p>
            @endif
        </div>    
        <div class="col-md-6">
              <h2>{{__('about.ourmission')}}</h2>
              @if(app()->getLocale()=='en')
            <p>{{$details['mission']}}</p>
            @else
            <p>{{$details['mission_ar']}}</p>
            @endif
        </div>    
          </div>       
        </div>       
@endsection