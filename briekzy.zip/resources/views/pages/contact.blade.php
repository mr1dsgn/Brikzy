@extends('layouts.app')
@section('content')
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                      <a href="{{url('')}}">{{__('home.home')}}</a> / <span>{{__('home.contact')}}</span>
                  </div>
                  <h1>{{__('home.contact')}}</h1>
                </div>
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->
      
      <section class="probootstrap-section">
        <div class="container">
          <div class="row">
            <div class="col-md-8">
              <form action="{{url('contact')}}" method="post" class="probootstrap-form mb60">
                  {{ csrf_field() }}
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                    <label for="fname">{{__('contact.firstname')}}</label>
                      <input type="text" class="form-control" id="fname" name="fname"  required="required">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="lname">{{__('contact.lastname')}}</label>
                      <input type="text" class="form-control" id="lname" name="lname"  required="required">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label for="email">{{__('contact.email')}}</label>
                  <input type="email" class="form-control" id="email" name="email"  required="required">
                </div>
                <div class="form-group">
                  <label for="message">{{__('contact.message')}}</label>
                  <textarea cols="30" rows="10" class="form-control" id="message" name="message" required="required"></textarea>
                </div>
                <div class="form-group">
                  <input type="submit" class="btn btn-primary" id="submit" name="submit" value="{{__('contact.sendmessage')}}">
                </div>
              </form>
            </div>
            <div class="col-md-3 col-md-push-1">
            <h4>{{__('contact.contactdetails')}}</h4>
              <ul class="with-icon colored">
              <li><i class="icon-location2"></i> <span>{{__('home.address1')}}</span></li>
                <li><i class="icon-mail"></i><span>info@brickzey.com</span></li>
                <li><i class="icon-phone2"></i><span>19693</span></li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <div id="map"></div>
@endsection
@section('scripts')
<script>
        
        function initMap() {
            var latitude = 30.019949;
            var longitude = 31.003611;
            var uluru = {lat: latitude, lng: longitude};
            var map = new google.maps.Map(document.getElementById('map'), {
            center: uluru,
            zoom: 15
          });
          
          var marker = new google.maps.Marker({
            position: uluru,
            map: map
          });
        }
  
      </script>
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCexG_fKuUyNzxEYYZHd_2rngKejCQnzbw&callback=initMap"
      async defer></script>
@endsection