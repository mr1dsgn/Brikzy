<!DOCTYPE html>

<html lang="{{app()->getLocale()}}" dir = "{{(app()->getLocale() == "en")?'ltr':'rtl'}}">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @if(isset($page))
      @if(app()->getLocale() == "en")
      <title>{{$page->title_en}}</title>
      @else
      <title>{{$page->title_ar}}</title>
      @endif
      <meta name="description" content="{{$page->description}}">
      <meta name="keywords" content="{{$page->keywords}}">
      @php
        $page_name=$page->name;
      @endphp
    @else
    <title>Brickzey</title>
    @php
        $page_name='home';
    @endphp
    @endif
    @php
    $homeDetails=$homePage->details();
    @endphp
    <meta name="format-detection" content="telephone=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
        
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet">
    <link rel="stylesheet" href="{{url('')}}/css/styles-merged.css">
    <link rel="stylesheet" href="{{url('')}}/css/style.css">
    <link rel="stylesheet" href="{{url('')}}/css/custom.css">
    <link rel="stylesheet" href="{{url('')}}/css/bootstrap-slider.min.css">
    @if(app()->getLocale() == "ar")
    <link rel="stylesheet" href="{{url('')}}/css/rtl.css">
    @endif
    @yield('css')

    <!--[if lt IE 9]>
    <script src="{{url('')}}/js/vendor/html5shiv.min.js"></script>
      <script src="{{url('')}}/js/vendor/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

  <!-- START: header -->
  
  <div class="probootstrap-loader"></div>

  <header role="banner" class="probootstrap-header">
    <div class="container">
        <a href="{{url('')}}" class="probootstrap-logo"><img src="{{url('')}}/img/logo.png" alt="Brickzey"/></a>
        <a href="#" class="probootstrap-burger-menu visible-xs" ><i></i></a>
        <div class="mobile-menu-overlay"></div>
        <nav role="navigation" class="probootstrap-nav hidden-xs">
          <ul class="probootstrap-main-nav">
          <li class="{{($page_name=='home'?'active':'')}}"><a href="{{url('')}}">{{__('home.home')}}</a></li>
            <li class="{{($page_name=='about'?'active':'')}}"><a href="{{url('about')}}">{{__('home.about')}}</a></li>
            <li class="{{($page_name=='projects'?'active':'')}}"><a href="{{url('projects')}}">{{__('home.projects')}}</a></li>
            <li class="{{($page_name=='units'?'active':'')}}"><a href="{{url('units')}}">{{__('home.units')}}</a></li>
            <li class="{{($page_name=='offers'?'active':'')}}"><a href="{{url('offers')}}">{{__('home.offers')}}</a></li>
            <li class="dropdown {{($page_name=='photos' || $page_name=='videos' || $page_name=='pdfs')?'active':''}}">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">{{__('home.media')}} <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="{{url('photos')}}">{{__('home.photos')}}</a></li>
                <li><a href="{{url('videos')}}">{{__('home.videos')}}</a></li>
                <li><a href="{{url('pdfs')}}">{{__('home.newsletter')}}</a></li>
              </ul>
            </li>
            <li class="{{($page_name=='contact'?'active':'')}}"><a href="{{url('/contact')}}">{{__('home.contact')}}</a></li>
            @if(app()->getLocale() == "en")
            <li><a style="font-size:20px;font-weight:bold;color:#912417;" href="{{url('language/ar')}}"><span style="font-family:arFont;">ع</span><span style="text-transform: none;"> / Ar</span></a></li>
            @else
            <li><a style="font-size:20px;font-weight:bold;color:#912417" href="{{url('language/en')}}">En</a></li>
            @endif
          </ul>
          <div class="extra-text visible-xs"> 
            <a href="#" class="probootstrap-burger-menu"><i></i></a>
            <h5>{{__('home.address')}}</h5>
            <p>{{__('home.address1')}}</p>
            <h5>{{__('home.connect')}}</h5>
            <ul class="social-buttons">
                <li><a target="_blank" href="https://www.facebook.com/Brickzeypropertymanagement/"><i class="icon-facebook"></i></a></li>
                <li><a target="_blank" href="https://www.facebook.com/Brickzeypropertymanagement/"><i class="icon-instagram2"></i></a></li>
                <li><a target="_blank" href="https://twitter.com/brickzey"><i class="icon-twitter"></i></a></li>
                <li><a target="_blank" href="https://ae.linkedin.com/company/brickzey-property-management"><i class="icon-linkedin"></i></a></li>
            </ul>
          </div>
        </nav>
    </div>
  </header>
  <!-- END: header -->
  @yield('content')
  <footer class="probootstrap-footer probootstrap-bg" style="background-image: url(img/slider_3.jpg)">
    <div class="container">
      <div class="row mb60">
        <div class="col-md-3">
          <div class="probootstrap-footer-widget">
            <h4 class="heading">{{__('home.aboutbrickzey')}}</h4>
            @if(app()->getLocale()=='en')
            {{$homeDetails['about']}}
            @else
            {{$homeDetails['about_ar']}}
            @endif
            <p><a href="{{url('about')}}">{{__('home.readmore')}}</a></p>
          </div> 
        </div>
        <div class="col-md-3">
          <div class="probootstrap-footer-widget probootstrap-link-wrap">
            <h4 class="heading">{{__('home.quicklinks')}}</h4>
            <ul class="stack-link">
              <li><a href="{{url('projects')}}">{{__('home.projects')}}</a></li>
              <li><a href="{{url('units')}}">{{__('home.units')}}</a></li>
              <li><a href="{{url('photos')}}">{{__('home.photos')}}</a></li>
              <li><a href="{{url('videos')}}">{{__('home.videos')}}</a></li>
              <li><a href="{{url('pdfs')}}">{{__('home.newsletter')}}</a></li>
              <li><a href="{{url('contact')}}">{{__('home.contact')}}</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-3">
          <div class="probootstrap-footer-widget">
            <h4 class="heading">{{__('home.popcities')}}</h4>
            <ul class="stack-link">
              @foreach($propResults as $p)
              @if(app()->getLocale() == "en")
            <li><a href="{{url('units?location='.$p->id)}}">{{$p->name_en}} <small>({{$p->vcount}} properties)</small></a></li>
              @else
              <li><a href="{{url('units?location='.$p->id)}}">{{$p->name_ar}} <small>{{$p->vcount}} وحدات)</small></a></li>
              @endif              
              @endforeach
            </ul>
          </div> 
        </div>
        <div class="col-md-3">
          <div class="probootstrap-footer-widget probootstrap-link-wrap">
            <h4 class="heading">{{__('home.subscribe')}}</h4>
            <p>{{__('home.subscribe1')}}</p>
            <form action="{{url('subscribe')}}" method="post">
                {{ csrf_field() }}
              <div class="form-field">
                <input type="email" class="form-control" placeholder="{{__('home.enteremail')}}" required="required" name="email">
                <button class="btn btn-subscribe" type="submit">{{__('home.send')}}</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="row copyright">
        <div class="col-md-6">
          <div class="probootstrap-footer-widget">
            <p>&copy; 2018 <a href="http://www,brickzey.com/">{{__('home.brickzey')}}</a></p>
          </div>
        </div>
        <div class="col-md-6">
          <div class="probootstrap-footer-widget right">
            <ul class="probootstrap-footer-social">
              <li><a target="_blank" href="https://www.facebook.com/Brickzeypropertymanagement/"><i class="icon-facebook"></i></a></li>
              <li><a target="_blank" href="https://www.facebook.com/Brickzeypropertymanagement/"><i class="icon-instagram2"></i></a></li>
              <li><a target="_blank" href="https://twitter.com/brickzey"><i class="icon-twitter"></i></a></li>
              <li><a target="_blank" href="https://ae.linkedin.com/company/brickzey-property-management"><i class="icon-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="icon-chevron-thin-up"></i></a>
  </div>
  <!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">          
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="{{url('callme')}}" method="post" class="probootstrap-form mb60">
            {{ csrf_field() }}
        <div class="modal-body">            
        <p>{{__('contact.welcome')}}</p>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="fname">{{__('contact.firstname')}}</label>
                      <input type="text" class="form-control" id="fname" name="fname" required="required">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="lname">{{__('contact.lastname')}}</label>
                      <input type="text" class="form-control" id="lname" name="lname" required="required">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label for="email">{{__('contact.email')}}</label>
                  <input type="email" class="form-control" id="email" name="email"  required="required">
                </div>
                <div class="form-group">
                    <label for="phone">{{__('contact.number')}}</label>
                    <input type="phone" class="form-control" id="phone" name="phone"  required="required">
                  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">{{__('contact.close')}}</button>
          <button class="btn btn-primary" type="submit">{{__('contact.sendmessage')}}</button>
        </div>
      </form>
      </div>
    </div>
  </div>
  <script src="{{url('')}}/js/scripts.min.js"></script>
  <script src="{{url('')}}/js/main.js"></script>
  <script src="{{url('')}}/js/custom.js"></script>
  <script src="{{url('')}}/js/bootstrap-slider.min.js"></script>
  <script src="{{url('')}}/js/jquery.countdown.min.js"></script>
  @yield('scripts')
  
  <script type="text/javascript">
    $("#ex1").slider({});
    $("#ex2").slider({});
    @if(Session::has('message'))
    alert('{{Session::get('message')}}');
    @endif
  </script>
  
  </body>
</html>