@extends('layouts.app')
@section('content')
<section class="probootstrap-slider flexslider2 page-inner">
        <div class="overlay"></div>
        <div class="probootstrap-wrap-banner">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
    
                <div class="page-title probootstrap-animate">
                  <div class="probootstrap-breadcrumbs">
                    <a href="{{url('')}}">{{__('home.home')}}</a> / <span>{{__('home.units')}}</span>
                  </div>
                  <h1>{{__('home.units')}}</h1>
                </div>
    
              </div>
            </div>
          </div>
        </div>
        @php
        $slides=$page->slides()->get();
        @endphp
        @if(count($slides)>0)
        <ul class="slides">
          @foreach($slides as $slide)
          <li style="background-image: url({{url('').'/'.$slide->url}});" class=""></li>
          @endforeach
        </ul>
        @endif
      </section>
      <!-- END: slider  -->

      <section class="probootstrap-section probootstrap-section-lighter">
          <div class="container">
            <div class="row heading">
              <h2 class="mt0 mb50 text-center">{{__('home.units')}}</h2>
            </div>
            
          <div class="row">
              @php
              $i=0;
              @endphp
              @foreach($units as $unit)
              <div class="col-md-4 col-sm-6">
                <div class="probootstrap-card probootstrap-listing">
                  <div class="probootstrap-card-media">
                    @if(app()->getLocale() == "en")
                    <img src="{{url($unit->image)}}" class="img-responsive" alt="{{$unit->name_en}}">
                    @else
                    <img src="{{url($unit->image)}}" class="img-responsive" alt="{{$unit->name_ar}}">
                    @endif
                  </div>
                  <div class="probootstrap-card-text">
                    <h2 class="probootstrap-card-heading">
                      <a href="{{url('units/'.$unit->id)}}">
                        @if(app()->getLocale() == "en")
                        {{$unit->name_en}}
                        @else
                        {{$unit->name_ar}}
                        @endif
                      </a>
                    </h2>
                    <div class="probootstrap-listing-location">
                        @if(app()->getLocale() == "en")
                        <span>{{$unit->description_en}}</span>
                        @else
                        <span>{{$unit->description_ar}}</span>
                        @endif
                    </div>
                    <div class="probootstrap-listing-price"><strong> {{$unit->price.' '.__('home.egp')}} </strong></div>
                  </div>
                  <div class="probootstrap-card-extra">
                    <ul>
                      <li>
                          {{__('home.area')}}
                        <span>{{$unit->area .' '.__('home.m2')}}</span>
                      </li>
                      <li>
                          {{__('home.beds')}}
                        <span>{{$unit->beds}}</span>
                      </li>
                      <li>
                          {{__('home.baths')}}
                        <span>{{$unit->baths}}</span>
                      </li>
                      <li>
                          {{__('home.location')}}
                        @php
                        $location=$unit->location()->first();
                        @endphp
                        @if(app()->getLocale() == "en")
                        <span>{{$location->name_en}}</span>
                        @else
                        <span>{{$location->name_ar}}</span>
                        @endif
                      </li>
                    </ul>
                  </div>
                </div>
                <!-- END listing -->
              </div>
              @if((++$i)%2==0)
              <div class="clearfix visible-sm-block"></div>
              @endif
              @endforeach
            </div>
          </div>
        </section>   
      @endsection